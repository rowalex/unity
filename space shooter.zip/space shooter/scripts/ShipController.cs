﻿using UnityEngine;
using System.Collections;

[System.Serializable]
public class Boundary
{
    public float xMin, xMax, zMin, zMax;
}

public class ShipController : MonoBehaviour
{
    [SerializeField] Rigidbody rg2d;

    public float speed;
    public float tilt;
    public Boundary boundary;

    [SerializeField] GameObject bolt;
    [SerializeField] Transform spawn;

    private float timer = 0.5f;

    void Update()
    {
        timer = timer - Time.deltaTime;
        if(Input.GetKey(KeyCode.Space) && timer<=0)
        {
            timer = 0.5f;
            Instantiate(bolt, spawn.position,  spawn.rotation );
        }
    }

    void FixedUpdate()
    {
        float moveHorizontal = Input.GetAxis("Horizontal");
        float moveVertical = Input.GetAxis("Vertical");

        Vector3 movement = new Vector3(moveHorizontal, 0.0f, moveVertical);
      rg2d.velocity = movement * speed;

        rg2d.position = new Vector3
        (
            Mathf.Clamp(rg2d.position.x, boundary.xMin, boundary.xMax),
            0.0f,
            Mathf.Clamp(rg2d.position.z, boundary.zMin, boundary.zMax)
        );

        rg2d.rotation = Quaternion.Euler(0.0f, 0.0f, rg2d.velocity.x * -tilt);
    }
}