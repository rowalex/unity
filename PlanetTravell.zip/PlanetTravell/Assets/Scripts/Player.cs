﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : MonoBehaviour
{

    [SerializeField] Transform Planet;

    [SerializeField] Rigidbody2D rg;

    [SerializeField] float Gravity;

    [SerializeField] float JumpPower;

    public LayerMask Ground;

    [SerializeField] bool inobject = false;

    [SerializeField] float speed;

    void Gravitation()
    {
        Vector3 dir = (Planet.position - transform.position).normalized;

        rg.AddForce(dir * Gravity);
        transform.up = -dir;
    }

    void Jump()
    {
        Vector3 dir = (Planet.position - transform.position).normalized;




        if (Input.GetKey(KeyCode.W) && RaycastForGround() == true)
        {
            rg.velocity = -dir * JumpPower;
        }else
        if (Input.GetKeyDown(KeyCode.W) && RaycastForWall() == true && inobject == true)
        {
            rg.velocity = -dir * JumpPower;
            inobject = false;
        }
    }



    void Movement()
    {
        if (Input.GetKey(KeyCode.D))
            transform.position += transform.right * speed * Time.deltaTime;
        if (Input.GetKey(KeyCode.A))
            transform.position += -transform.right * speed * Time.deltaTime;
    }


    private bool RaycastForGround()
    {
        RaycastHit2D hit;
        hit = Physics2D.Raycast(transform.localPosition, -transform.up, 0.5f, Ground);
        if (hit == true)
        {
            inobject = true;
        }
        return hit;
    }

    private bool RaycastForWall()
    {
        RaycastHit2D hit;

        hit = Physics2D.Linecast(transform.position + transform.right.normalized * 0.5f,
            transform.position - transform.right.normalized * 0.5f, Ground);
        return hit;
    }

    private void FixedUpdate()
    {

        Gravitation();
        Jump();
        Movement();

    }

}
