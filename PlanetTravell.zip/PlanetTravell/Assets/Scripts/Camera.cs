﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Camera : MonoBehaviour {

    [SerializeField] Transform Target;

    [SerializeField] float SmoothSpeed;

    [SerializeField] Vector3 offset;

    private void FixedUpdate()
    {
        Vector3 original = Target.position + offset;
        Vector3 smooth = Vector3.Lerp(original, transform.position, SmoothSpeed);

        transform.position = smooth;

        transform.rotation = Target.rotation;
    }
}
