﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class asteroid : MonoBehaviour {

   [SerializeField] private Rigidbody rg2d;

    [SerializeField] private GameObject Boundary;
    [SerializeField] private  GameObject player;
    [SerializeField] private Transform player1;

    [SerializeField] private GameObject expl;
    [SerializeField] private GameObject playerexpl;

    [SerializeField] private float tumble;

    void Start()
    {
        rg2d.angularVelocity = Random.insideUnitSphere * tumble;
    }

    void OnTriggerEnter(Collider other)
    {
        if (other.gameObject == Boundary)
        {
            return;
        }
        Instantiate(expl, transform.position, transform.rotation);
        if(other.gameObject == player)
        {
            Instantiate(playerexpl, player1.position, player1.rotation);
            
        }

        Destroy(other.gameObject);
        Destroy(gameObject);
    }
}
