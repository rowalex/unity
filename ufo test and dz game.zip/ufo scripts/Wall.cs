﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Wall : MonoBehaviour {

    int hp = 100;


    void OnCollisionEnter2D(Collision2D other)
    {
        if (other.gameObject.CompareTag("Bullet"))
        {
            hp -= 20;
            Destroy(other.gameObject);
        }
        if (hp<=0)
        {
            Destroy(gameObject);
        }
    }
	
}
