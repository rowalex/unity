﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BoltMove : MonoBehaviour {

    public Rigidbody rg2d;
    public float speed;

    void Start()
    {
        rg2d.velocity = transform.up * speed; 
    }


}
