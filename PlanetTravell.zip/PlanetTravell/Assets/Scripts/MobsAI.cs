﻿using UnityEngine;

public class MobsAI : MonoBehaviour {

    [SerializeField]
    float Speed;

    [SerializeField]
    float Gravitation;

    [SerializeField]
    Transform Planet;

    [SerializeField]
    Rigidbody2D rg;

    [SerializeField]
    float Board1;

    [SerializeField]
    float Board2;

    [SerializeField]
    bool Board1Activation;

    [SerializeField]
    bool GoRight;

    [SerializeField]
    LayerMask Wall;

     float timer;

    float go_out;

    private float overtime;

    private bool Ready = true;

    private int a;

    [SerializeField] BoxCollider2D PlayerBx;

    [SerializeField] BoxCollider2D MineBx;


    private void Start()
    {
        a = Random.Range(0, 2);
        if(a == 1)
        {
            Board1Activation = true;
            timer = Board1;
        }
        else
        {
            Board1Activation = false;
            timer = Board2;
        }

    }

    void Gravity()
    {
        Vector3 dir = (Planet.position - transform.position).normalized;
        rg.AddForce(dir * Gravitation);
        transform.up = -dir;
    }

    void MoveRight()
    {
        transform.position += transform.right * Speed * Time.deltaTime;
        if(timer <= 0)
        {
            Board1Activation = false;
            timer = Board1 + Board2;
        }
    }

    void MoveLeft()
    {
        transform.position -= transform.right * Speed * Time.deltaTime;
        if (timer <= 0)
        {
            Board1Activation = true;
            timer = Board1 + Board2;
        }
    }

    private bool WallTouch()
    {
        RaycastHit2D hit;

            hit = Physics2D.Linecast(transform.position + transform.right.normalized * 0.5f,
               transform.position - transform.right.normalized * 0.5f, Wall);
        
            return hit;
    }


    private void FixedUpdate()
    {
        if (MineBx.IsTouching(PlayerBx))
        {
            Destroy(gameObject);
        }

        if(go_out <= 0)
        if (WallTouch())
        {
            overtime = timer;
            Board1Activation = !Board1Activation;
                timer = Board1 + Board2 - overtime;
            go_out = 1;

        }

            timer -= Time.deltaTime;
            if (Board1Activation == true)
                MoveRight();
            else
                MoveLeft();
   

        Gravity();
      
    }

}
