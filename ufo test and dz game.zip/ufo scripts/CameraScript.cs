﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraScript : MonoBehaviour {

    [SerializeField] private Transform playerTransform;

    private Vector3 newPos = Vector3.zero;


    void Start()
    {
        newPos.z = -10;
    }

    void LateUpdate()
    {
        newPos.x = playerTransform.position.x;
        newPos.y = playerTransform.position.y;

        transform.position = newPos;
    }


}
