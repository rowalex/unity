﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : MonoBehaviour {

    [SerializeField] private float speed;
    [SerializeField] private float rotationSpeed;
    [SerializeField] private GameObject tower;
    [SerializeField] private GameObject bullet;
    [SerializeField] private Transform gunTransform;
    [SerializeField] private float timer = 0;
    [SerializeField] private AudioSource source;
    [SerializeField] private GameObject sparkles;

    float hor;
    float vert;
    


    void Update()
    {
        timer -= Time.deltaTime;
        hor = Input.GetAxis("Horizontal");
        vert = Input.GetAxis("Vertical");

        transform.Translate(Vector2.up * speed * vert * Time.deltaTime);
        transform.Rotate(new Vector3(0, 0, -180) * rotationSpeed * hor * Time.deltaTime);

        //Чтобы двумерный обьект смотрел на мышку или другой обьект
        Vector3 mousepos = Camera.main.ScreenToWorldPoint(new Vector3(Input.mousePosition.x, Input.mousePosition.y, 0));
        Vector3 diff = mousepos - transform.position;
        diff.Normalize();
        float rot_z = Mathf.Atan2(diff.y, diff.x) * Mathf.Rad2Deg;
        tower.transform.rotation = Quaternion.Lerp(tower.transform.rotation, Quaternion.Euler(0f, 0f, rot_z - 90), Time.deltaTime * 2);
        //-------------------------------------------------------//

        if (Input.GetMouseButtonDown(0) && timer<= 0)
        {
            Shoot();
            timer = 1;
        }
    }

    void Shoot()
    {
        Instantiate(bullet, gunTransform.position, tower.transform.rotation);
        source.pitch = Random.Range(0, 2f);
        source.Play();
    }

    void OnTriggerEnter2D(Collider2D other)
    {
        if (other.gameObject.CompareTag("Bomb"))
        {
            Destroy(other.gameObject);
            sparkles.SetActive(true);
            enabled = false;
        }
    }

}
