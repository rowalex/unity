﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Objects : MonoBehaviour {

    [SerializeField] Transform Planet;

    private void Start()
    {
        Vector3 dir = (Planet.position - transform.position).normalized;
        transform.up = -dir;
    }
}
